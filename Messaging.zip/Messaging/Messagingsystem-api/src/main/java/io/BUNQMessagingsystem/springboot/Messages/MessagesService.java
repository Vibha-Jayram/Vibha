package io.BUNQMessagingsystem.springboot.Messages;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


@Service
public class MessagesService {

	@Autowired
	private MessagesRepository messagesRepository;
	
	public void addMessages(Messages messages) {
		messagesRepository.save(messages);		
		
	}
	public List<Messages> getAllMessages(String userid){
		List<Messages> messages = new ArrayList<>();
		messagesRepository.findByUsersUserid(userid)
		.forEach(messages::add);
		return messages;
		
	}
	
		
	
}
