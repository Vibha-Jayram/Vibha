package io.BUNQMessagingsystem.springboot.Messages;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface MessagesRepository extends CrudRepository<Messages, String> {

	public List<Messages> findByUsersUserid(String userid);

	
	
	
}
