

package io.BUNQMessagingsystem.springboot.Users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UsersController {
	
	@Autowired
	private UsersService userService;
	
	@RequestMapping(method=RequestMethod.POST,value="/Users")
	public void addUsers(@RequestBody Users uesrs) {
		userService.addUsers(uesrs);
	}
			
	@RequestMapping("/Users")
	public List<Users> getAllUsers() {
		return userService.getAllUsers();
		
	}
	
	@RequestMapping("/Users/{User_id}")
	public Users getUsers(@PathVariable String User_id) {
		return userService.getUsers(User_id);
	}

}
