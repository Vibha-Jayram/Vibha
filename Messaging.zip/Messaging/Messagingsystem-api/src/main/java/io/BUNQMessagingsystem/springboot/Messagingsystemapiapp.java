package io.BUNQMessagingsystem.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Messagingsystemapiapp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(Messagingsystemapiapp.class, args);
		

	}

}
