package io.BUNQMessagingsystem.springboot.Users;


import javax.persistence.Entity;
import javax.persistence.Id;


@Entity

public class Users {
	
 @Id	
 private String userid;
 private String email_id;
 private String name;
 
 public Users() {
	 
 }
 
 public Users(String userid, String email_id, String name) {
	super();
	this.userid = userid;
	this.email_id = email_id;
	this.name = name;
}

public String getuserid() {
	return userid;
}

public void setuserid(String userid) {
	this.userid = userid;
}

public String getEmail_id() {
	return email_id;
}

public void setEmail_id(String email_id) {
	this.email_id = email_id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
 
  
 
	
}

