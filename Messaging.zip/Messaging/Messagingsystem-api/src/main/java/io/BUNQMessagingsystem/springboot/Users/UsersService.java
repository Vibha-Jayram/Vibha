package io.BUNQMessagingsystem.springboot.Users;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class UsersService {
	
	@Autowired
	private UsersRepository usersRepository;
    
	
	public void addUsers(Users users) {
		usersRepository.save(users);		
		
	}
	
	
	public List<Users> getAllUsers(){
		List<Users> users = new ArrayList<>();
		usersRepository.findAll()
		.forEach(users::add);
		return users;
		
	}
	
	public Users getUsers(String User_id) {
		return usersRepository.findOne(User_id);
		
		
	}


}
