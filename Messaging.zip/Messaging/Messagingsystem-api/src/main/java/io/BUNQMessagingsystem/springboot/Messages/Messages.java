package io.BUNQMessagingsystem.springboot.Messages;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import io.BUNQMessagingsystem.springboot.Users.Users;;

@Entity

public class Messages {

	@Id
	private String msg_id;
	private String msg;
	private String authorname;
	
	@ManyToOne
	private Users users;
	
	
	public Messages() {
		
	}

	public Messages(String msg_id, String msg, String authorname , String userid) {
		super();
		this.msg_id = msg_id;
		this.msg = msg;
		this.authorname = authorname;
		this.users = new Users(userid,"","");
	}

	public String getMsg_id() {
		return msg_id;
	}

	public void setMsg_id(String msg_id) {
		this.msg_id = msg_id;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getauthorname() {
		return authorname;
	}

	public void setauthorname(String authorname) {
		this.authorname = authorname;
	}

	public Users getUsers() {
		return users;
	}

	public void setUsers(Users users) {
		this.users = users;
	}

	
	
	}
